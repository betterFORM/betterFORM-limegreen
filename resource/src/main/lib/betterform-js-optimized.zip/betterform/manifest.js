/*
* Copyright (c) 2010. betterForm Project - http://www.betterform.de
* All Rights Reserved.
*
* @author Tobias Krebs
* @author Joern Turner
* @author Lars Windauer
*
* Licensed under the terms of BSD License
*
*/

if(!dojo._hasResource["betterform.manifest"]){dojo._hasResource["betterform.manifest"]=true;dojo.provide("betterform.manifest");dojo.registerNamespaceResolver(function(_1){return "betterform.widgets.variousWidgets";});}